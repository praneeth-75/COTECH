package com.task2.SimpleBlogApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleBlogAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
