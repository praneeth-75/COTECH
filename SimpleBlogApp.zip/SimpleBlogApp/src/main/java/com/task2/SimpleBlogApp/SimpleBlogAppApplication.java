package com.task2.SimpleBlogApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleBlogAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleBlogAppApplication.class, args);
	}

}
